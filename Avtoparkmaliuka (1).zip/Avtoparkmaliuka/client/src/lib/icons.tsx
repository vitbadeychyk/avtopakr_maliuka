import { Bike, Car, Baby, Armchair, Footprints, Bed, Utensils, Gamepad2 } from "lucide-react";

export const categoryIconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Bike,
  Car,
  Baby,
  Armchair,
  Footprints,
  Bed,
  Utensils,
  Gamepad2,
};

export function getCategoryIcon(iconName: string) {
  return categoryIconMap[iconName] || Bike;
}
