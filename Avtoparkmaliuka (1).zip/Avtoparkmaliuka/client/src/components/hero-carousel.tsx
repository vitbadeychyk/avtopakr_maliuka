import { useState, useEffect, useCallback } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface HeroSlide {
  id: string;
  title: string;
  subtitle: string;
  buttonText: string;
  buttonLink: string;
  gradient: string;
}

const slides: HeroSlide[] = [
  {
    id: "1",
    title: "Велосипеди для всієї родини",
    subtitle: "Знижки до 30% на весь асортимент дитячих та підліткових велосипедів",
    buttonText: "Переглянути",
    buttonLink: "/catalog/velosypedy",
    gradient: "from-emerald-600 to-teal-500",
  },
  {
    id: "2",
    title: "Дитячі електромобілі",
    subtitle: "Подаруйте своїй дитині справжню радість! Новинки сезону вже у продажу",
    buttonText: "Обрати електромобіль",
    buttonLink: "/catalog/elektromobili",
    gradient: "from-orange-500 to-amber-400",
  },
  {
    id: "3",
    title: "Коляски преміум класу",
    subtitle: "Комфорт та безпека для вашого малюка. Безкоштовна доставка по Україні",
    buttonText: "Дивитись коляски",
    buttonLink: "/catalog/kolyasky",
    gradient: "from-violet-600 to-purple-500",
  },
  {
    id: "4",
    title: "Все для дитячої кімнати",
    subtitle: "Меблі, ліжечка та аксесуари найвищої якості для вашої дитини",
    buttonText: "До каталогу",
    buttonLink: "/catalog/lizhka",
    gradient: "from-sky-500 to-blue-500",
  },
];

export function HeroCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const nextSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  }, []);

  useEffect(() => {
    if (!isAutoPlaying) return;
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, [isAutoPlaying, nextSlide]);

  return (
    <div
      className="relative w-full h-[50vh] md:h-[60vh] overflow-hidden"
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute inset-0 transition-opacity duration-700 ${
            index === currentSlide ? "opacity-100 z-10" : "opacity-0 z-0"
          }`}
        >
          <div className={`absolute inset-0 bg-gradient-to-br ${slide.gradient}`} />
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
          
          <div className="relative h-full max-w-7xl mx-auto px-4 flex items-center">
            <div className="max-w-xl text-white">
              <h1 className="text-3xl md:text-5xl font-extrabold mb-4 drop-shadow-lg">
                {slide.title}
              </h1>
              <p className="text-lg md:text-xl mb-6 opacity-95 drop-shadow">
                {slide.subtitle}
              </p>
              <Link href={slide.buttonLink}>
                <Button
                  size="lg"
                  className="bg-white text-foreground hover:bg-white/90 font-bold shadow-lg"
                  data-testid={`button-hero-${slide.id}`}
                >
                  {slide.buttonText}
                </Button>
              </Link>
            </div>
          </div>
        </div>
      ))}

      <Button
        size="icon"
        variant="ghost"
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 bg-white/20 backdrop-blur-sm text-white hover:bg-white/30"
        data-testid="button-hero-prev"
      >
        <ChevronLeft className="w-6 h-6" />
      </Button>
      
      <Button
        size="icon"
        variant="ghost"
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-10 h-10 bg-white/20 backdrop-blur-sm text-white hover:bg-white/30"
        data-testid="button-hero-next"
      >
        <ChevronRight className="w-6 h-6" />
      </Button>

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 flex items-center gap-2">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-2.5 h-2.5 rounded-full transition-all ${
              index === currentSlide
                ? "bg-white w-8"
                : "bg-white/50 hover:bg-white/75"
            }`}
            data-testid={`button-hero-dot-${index}`}
          />
        ))}
      </div>
    </div>
  );
}
