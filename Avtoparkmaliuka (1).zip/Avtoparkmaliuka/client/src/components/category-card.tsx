import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Bike, Car, Baby, Armchair, Footprints, Bed, Utensils, Gamepad2 } from "lucide-react";
import type { Category, Subcategory } from "@shared/schema";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Bike,
  Car,
  Baby,
  Armchair,
  Footprints,
  Bed,
  Utensils,
  Gamepad2,
};

interface CategoryCardProps {
  category: Category;
}

export function CategoryCard({ category }: CategoryCardProps) {
  const IconComponent = iconMap[category.icon] || Bike;

  return (
    <Link href={`/catalog/${category.slug}`}>
      <Card 
        className="group h-full overflow-visible hover-elevate active-elevate-2 transition-all duration-300"
        data-testid={`card-category-${category.id}`}
      >
        <CardContent className="p-6 text-center">
          <div className="mb-4 flex justify-center">
            <IconComponent className="w-12 h-12 text-primary transition-transform duration-300 group-hover:scale-110" />
          </div>
          <h3 className="font-bold text-lg mb-2">{category.name}</h3>
          {category.subcategories.length > 0 && (
            <p className="text-sm text-muted-foreground">
              {category.subcategories.length} підкатегорій
            </p>
          )}
        </CardContent>
      </Card>
    </Link>
  );
}

interface SubcategoryCardProps {
  subcategory: Subcategory;
  categorySlug: string;
}

export function SubcategoryCard({ subcategory, categorySlug }: SubcategoryCardProps) {
  return (
    <Link href={`/catalog/${categorySlug}/${subcategory.slug}`}>
      <Card 
        className="group h-full overflow-visible hover-elevate active-elevate-2 transition-all duration-300"
        data-testid={`card-subcategory-${subcategory.id}`}
      >
        <CardContent className="p-4">
          <h3 className="font-semibold text-center">{subcategory.name}</h3>
        </CardContent>
      </Card>
    </Link>
  );
}
