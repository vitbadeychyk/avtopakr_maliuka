import { useState } from "react";
import { ChevronDown, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface FilterPanelProps {
  brands: string[];
  selectedBrands: string[];
  priceRange: [number, number];
  maxPrice: number;
  onBrandChange: (brands: string[]) => void;
  onPriceChange: (range: [number, number]) => void;
  onClearFilters: () => void;
}

export function FilterPanel({
  brands,
  selectedBrands,
  priceRange,
  maxPrice,
  onBrandChange,
  onPriceChange,
  onClearFilters,
}: FilterPanelProps) {
  const [priceOpen, setPriceOpen] = useState(true);
  const [brandsOpen, setBrandsOpen] = useState(true);

  const handleBrandToggle = (brand: string) => {
    if (selectedBrands.includes(brand)) {
      onBrandChange(selectedBrands.filter((b) => b !== brand));
    } else {
      onBrandChange([...selectedBrands, brand]);
    }
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("uk-UA", {
      style: "currency",
      currency: "UAH",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const hasActiveFilters = selectedBrands.length > 0 || priceRange[0] > 0 || priceRange[1] < maxPrice;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="font-bold text-lg">Фільтри</h2>
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClearFilters}
            className="text-destructive"
            data-testid="button-clear-filters"
          >
            <X className="w-4 h-4 mr-1" />
            Очистити
          </Button>
        )}
      </div>

      <Collapsible open={priceOpen} onOpenChange={setPriceOpen}>
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 font-semibold">
          Ціна
          <ChevronDown className={`w-4 h-4 transition-transform ${priceOpen ? "rotate-180" : ""}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-4 pb-2">
          <div className="px-2">
            <Slider
              value={priceRange}
              min={0}
              max={maxPrice}
              step={100}
              onValueChange={(value) => onPriceChange(value as [number, number])}
              className="mb-4"
              data-testid="slider-price"
            />
            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>{formatPrice(priceRange[0])}</span>
              <span>{formatPrice(priceRange[1])}</span>
            </div>
          </div>
        </CollapsibleContent>
      </Collapsible>

      <div className="border-t" />

      <Collapsible open={brandsOpen} onOpenChange={setBrandsOpen}>
        <CollapsibleTrigger className="flex items-center justify-between w-full py-2 font-semibold">
          Бренд
          <ChevronDown className={`w-4 h-4 transition-transform ${brandsOpen ? "rotate-180" : ""}`} />
        </CollapsibleTrigger>
        <CollapsibleContent className="pt-2 pb-2">
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {brands.map((brand) => (
              <div key={brand} className="flex items-center gap-2">
                <Checkbox
                  id={`brand-${brand}`}
                  checked={selectedBrands.includes(brand)}
                  onCheckedChange={() => handleBrandToggle(brand)}
                  data-testid={`checkbox-brand-${brand}`}
                />
                <Label
                  htmlFor={`brand-${brand}`}
                  className="text-sm cursor-pointer flex-1"
                >
                  {brand}
                </Label>
              </div>
            ))}
          </div>
        </CollapsibleContent>
      </Collapsible>
    </div>
  );
}
