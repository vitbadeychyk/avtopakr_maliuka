import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Search, ShoppingCart, Menu, ChevronDown, Sun, Moon, Phone, Bike, Car, Baby, Armchair, Footprints, Bed, Utensils, Gamepad2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useTheme } from "@/lib/theme";
import { useCart } from "@/lib/cart";
import type { Category } from "@shared/schema";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Bike, Car, Baby, Armchair, Footprints, Bed, Utensils, Gamepad2,
};

interface HeaderProps {
  categories: Category[];
  onSearch: (query: string) => void;
}

export function Header({ categories, onSearch }: HeaderProps) {
  const [location] = useLocation();
  const { theme, toggleTheme } = useTheme();
  const { itemCount } = useCart();
  const [searchQuery, setSearchQuery] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      onSearch(searchQuery.trim());
    }
  };

  const renderCategoryIcon = (iconName: string, className: string = "w-5 h-5") => {
    const IconComponent = iconMap[iconName] || Bike;
    return <IconComponent className={className} />;
  };

  return (
    <header className="sticky top-0 z-50 bg-background border-b">
      <div className="bg-primary text-primary-foreground py-1.5">
        <div className="max-w-7xl mx-auto px-4 flex items-center justify-between gap-4 text-sm">
          <div className="flex items-center gap-4">
            <a href="tel:+380441234567" className="flex items-center gap-1.5 hover:opacity-80 transition-opacity">
              <Phone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">+38 (044) 123-45-67</span>
            </a>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden md:inline">Безкоштовна доставка від 2000 грн</span>
            <Button
              size="icon"
              variant="ghost"
              onClick={toggleTheme}
              className="w-7 h-7 text-primary-foreground hover:bg-primary-foreground/10"
              data-testid="button-theme-toggle"
            >
              {theme === "light" ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center gap-4">
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild className="lg:hidden">
              <Button size="icon" variant="ghost" data-testid="button-mobile-menu">
                <Menu className="w-5 h-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-80 p-0">
              <div className="p-4 border-b">
                <Link href="/" onClick={() => setMobileMenuOpen(false)}>
                  <span className="text-2xl font-extrabold text-primary">We</span>
                  <span className="text-2xl font-extrabold text-secondary">Kids</span>
                </Link>
              </div>
              <nav className="p-4">
                {categories.map((cat) => (
                  <div key={cat.id} className="mb-2">
                    <Link
                      href={`/catalog/${cat.slug}`}
                      onClick={() => setMobileMenuOpen(false)}
                      className="flex items-center gap-3 p-3 rounded-md hover-elevate active-elevate-2"
                    >
                      {renderCategoryIcon(cat.icon, "w-5 h-5 text-primary")}
                      <span className="font-semibold">{cat.name}</span>
                    </Link>
                  </div>
                ))}
              </nav>
            </SheetContent>
          </Sheet>

          <Link href="/" className="flex-shrink-0" data-testid="link-logo">
            <span className="text-2xl md:text-3xl font-extrabold text-primary">We</span>
            <span className="text-2xl md:text-3xl font-extrabold text-secondary">Kids</span>
          </Link>

          <form onSubmit={handleSearch} className="flex-1 max-w-xl hidden md:flex">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Пошук товарів..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4"
                data-testid="input-search"
              />
            </div>
          </form>

          <div className="flex items-center gap-2 ml-auto">
            <Button size="icon" variant="ghost" className="md:hidden" data-testid="button-mobile-search">
              <Search className="w-5 h-5" />
            </Button>
            
            <Link href="/cart">
              <Button size="icon" variant="ghost" className="relative" data-testid="button-cart">
                <ShoppingCart className="w-5 h-5" />
                {itemCount > 0 && (
                  <Badge 
                    className="absolute -top-1 -right-1 h-5 min-w-5 flex items-center justify-center p-0 text-xs bg-secondary text-secondary-foreground"
                  >
                    {itemCount}
                  </Badge>
                )}
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <nav className="hidden lg:block border-t bg-card">
        <div className="max-w-7xl mx-auto px-4">
          <ul className="flex items-center gap-1">
            {categories.map((cat) => (
              <li
                key={cat.id}
                className="relative"
                onMouseEnter={() => setActiveCategory(cat.id)}
                onMouseLeave={() => setActiveCategory(null)}
              >
                <Link
                  href={`/catalog/${cat.slug}`}
                  className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold transition-colors hover:text-primary ${
                    location.includes(cat.slug) ? "text-primary" : ""
                  }`}
                  data-testid={`link-category-${cat.slug}`}
                >
                  {renderCategoryIcon(cat.icon, "w-4 h-4")}
                  <span>{cat.name}</span>
                  {cat.subcategories.length > 0 && <ChevronDown className="w-3.5 h-3.5" />}
                </Link>

                {cat.subcategories.length > 0 && activeCategory === cat.id && (
                  <div className="absolute top-full left-0 w-64 bg-popover border rounded-md shadow-lg p-2 z-50">
                    {cat.subcategories.map((sub) => (
                      <Link
                        key={sub.id}
                        href={`/catalog/${cat.slug}/${sub.slug}`}
                        className="block px-3 py-2 text-sm rounded-md hover-elevate active-elevate-2"
                        data-testid={`link-subcategory-${sub.slug}`}
                      >
                        {sub.name}
                      </Link>
                    ))}
                  </div>
                )}
              </li>
            ))}
          </ul>
        </div>
      </nav>
    </header>
  );
}
