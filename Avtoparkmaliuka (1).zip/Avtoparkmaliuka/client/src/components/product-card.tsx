import { Link } from "wouter";
import { ShoppingCart, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useCart } from "@/lib/cart";
import { useToast } from "@/hooks/use-toast";
import type { Product } from "@shared/schema";

interface ProductCardProps {
  product: Product;
  categorySlug?: string;
}

export function ProductCard({ product, categorySlug }: ProductCardProps) {
  const { addItem } = useCart();
  const { toast } = useToast();
  
  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0;

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addItem(product.id);
    toast({
      title: "Додано до кошика",
      description: product.name,
    });
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("uk-UA", {
      style: "currency",
      currency: "UAH",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  return (
    <Link href={`/product/${product.slug}`}>
      <Card 
        className="group h-full overflow-visible hover-elevate active-elevate-2 transition-all duration-300"
        data-testid={`card-product-${product.id}`}
      >
        <CardContent className="p-0">
          <div className="relative aspect-square overflow-hidden rounded-t-md">
            <img
              src={product.images[0] || "/placeholder-product.jpg"}
              alt={product.name}
              className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
              loading="lazy"
            />
            {discount > 0 && (
              <Badge 
                className="absolute top-2 right-2 bg-secondary text-secondary-foreground font-bold"
              >
                -{discount}%
              </Badge>
            )}
            {!product.inStock && (
              <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                <Badge variant="secondary">Немає в наявності</Badge>
              </div>
            )}
          </div>
          
          <div className="p-4">
            <p className="text-xs text-muted-foreground mb-1">{product.brand}</p>
            <h3 className="font-semibold text-sm line-clamp-2 min-h-[2.5rem] mb-2">
              {product.name}
            </h3>
            
            {product.rating > 0 && (
              <div className="flex items-center gap-1 mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-3.5 h-3.5 ${
                      i < Math.round(product.rating)
                        ? "fill-secondary text-secondary"
                        : "text-muted"
                    }`}
                  />
                ))}
                <span className="text-xs text-muted-foreground ml-1">
                  ({product.reviewCount})
                </span>
              </div>
            )}
            
            <div className="flex items-end justify-between gap-2 mt-auto">
              <div>
                <p className="text-lg font-bold text-primary">
                  {formatPrice(product.price)}
                </p>
                {product.oldPrice && (
                  <p className="text-sm text-muted-foreground line-through">
                    {formatPrice(product.oldPrice)}
                  </p>
                )}
              </div>
              
              <Button
                size="icon"
                onClick={handleAddToCart}
                disabled={!product.inStock}
                className="flex-shrink-0"
                data-testid={`button-add-to-cart-${product.id}`}
              >
                <ShoppingCart className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  );
}
