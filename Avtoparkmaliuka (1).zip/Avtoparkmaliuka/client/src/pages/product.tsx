import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { ChevronRight, Minus, Plus, ShoppingCart, Truck, Shield, RotateCcw, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useCart } from "@/lib/cart";
import { useToast } from "@/hooks/use-toast";
import { ProductCard } from "@/components/product-card";
import type { Product, Category } from "@shared/schema";

export default function ProductPage() {
  const { slug } = useParams<{ slug: string }>();
  const { addItem } = useCart();
  const { toast } = useToast();
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);

  const { data: product, isLoading } = useQuery<Product>({
    queryKey: ["/api/products", slug],
  });

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: relatedProducts } = useQuery<Product[]>({
    queryKey: ["/api/products/related", product?.categoryId],
    queryFn: async () => {
      if (!product?.categoryId) return [];
      const res = await fetch(`/api/products/related/${product.categoryId}?excludeId=${product.id}`);
      if (!res.ok) throw new Error("Failed to fetch related products");
      return res.json();
    },
    enabled: !!product?.categoryId,
  });

  const category = categories?.find((c) => c.id === product?.categoryId);
  const subcategory = category?.subcategories.find((s) => s.id === product?.subcategoryId);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("uk-UA", {
      style: "currency",
      currency: "UAH",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(price);
  };

  const handleAddToCart = () => {
    if (product) {
      addItem(product.id, quantity);
      toast({
        title: "Додано до кошика",
        description: `${product.name} x ${quantity}`,
      });
    }
  };

  const discount = product?.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0;

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8">
          <Skeleton className="aspect-square rounded-lg" />
          <div className="space-y-4">
            <Skeleton className="h-8 w-3/4" />
            <Skeleton className="h-6 w-1/4" />
            <Skeleton className="h-10 w-1/3" />
            <Skeleton className="h-24 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Товар не знайдено</h1>
        <Link href="/catalog">
          <Button>Повернутися до каталогу</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="bg-card border-b py-4">
        <div className="max-w-7xl mx-auto px-4">
          <nav className="flex items-center gap-2 text-sm text-muted-foreground flex-wrap">
            <Link href="/" className="hover:text-foreground transition-colors">
              Головна
            </Link>
            <ChevronRight className="w-4 h-4" />
            {category && (
              <>
                <Link
                  href={`/catalog/${category.slug}`}
                  className="hover:text-foreground transition-colors"
                >
                  {category.name}
                </Link>
                <ChevronRight className="w-4 h-4" />
              </>
            )}
            {subcategory && (
              <>
                <Link
                  href={`/catalog/${category?.slug}/${subcategory.slug}`}
                  className="hover:text-foreground transition-colors"
                >
                  {subcategory.name}
                </Link>
                <ChevronRight className="w-4 h-4" />
              </>
            )}
            <span className="text-foreground line-clamp-1">{product.name}</span>
          </nav>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          <div>
            <div className="aspect-square bg-card rounded-lg overflow-hidden mb-4 border">
              <img
                src={product.images[selectedImage] || "/placeholder-product.jpg"}
                alt={product.name}
                className="w-full h-full object-contain"
              />
            </div>
            {product.images.length > 1 && (
              <div className="flex gap-2 overflow-x-auto pb-2">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedImage(i)}
                    className={`w-20 h-20 flex-shrink-0 rounded-md overflow-hidden border-2 transition-colors ${
                      i === selectedImage ? "border-primary" : "border-transparent"
                    }`}
                    data-testid={`button-thumbnail-${i}`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} - ${i + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            )}
          </div>

          <div>
            <p className="text-sm text-muted-foreground mb-2">{product.brand}</p>
            <h1 className="text-2xl md:text-3xl font-bold mb-4">{product.name}</h1>

            {product.rating > 0 && (
              <div className="flex items-center gap-2 mb-4">
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.round(product.rating)
                          ? "fill-secondary text-secondary"
                          : "text-muted"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-sm text-muted-foreground">
                  {product.rating.toFixed(1)} ({product.reviewCount} відгуків)
                </span>
              </div>
            )}

            <div className="flex items-end gap-4 mb-6">
              <span className="text-3xl font-bold text-primary">
                {formatPrice(product.price)}
              </span>
              {product.oldPrice && (
                <>
                  <span className="text-xl text-muted-foreground line-through">
                    {formatPrice(product.oldPrice)}
                  </span>
                  <Badge className="bg-secondary text-secondary-foreground">
                    -{discount}%
                  </Badge>
                </>
              )}
            </div>

            <div className="flex items-center gap-2 mb-6">
              <Badge
                variant={product.inStock ? "default" : "secondary"}
                className={product.inStock ? "bg-primary" : ""}
              >
                {product.inStock ? "В наявності" : "Немає в наявності"}
              </Badge>
            </div>

            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center border rounded-md">
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  disabled={!product.inStock}
                  data-testid="button-quantity-minus"
                >
                  <Minus className="w-4 h-4" />
                </Button>
                <span className="w-12 text-center font-semibold">{quantity}</span>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => setQuantity(quantity + 1)}
                  disabled={!product.inStock}
                  data-testid="button-quantity-plus"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>

              <Button
                size="lg"
                onClick={handleAddToCart}
                disabled={!product.inStock}
                className="flex-1 gap-2"
                data-testid="button-add-to-cart"
              >
                <ShoppingCart className="w-5 h-5" />
                Додати до кошика
              </Button>
            </div>

            <div className="grid gap-3 p-4 bg-card rounded-lg border">
              <div className="flex items-center gap-3">
                <Truck className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-semibold text-sm">Безкоштовна доставка</p>
                  <p className="text-xs text-muted-foreground">При замовленні від 2000 грн</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Shield className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-semibold text-sm">Офіційна гарантія</p>
                  <p className="text-xs text-muted-foreground">До 3 років від виробника</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <RotateCcw className="w-5 h-5 text-primary" />
                <div>
                  <p className="font-semibold text-sm">Повернення</p>
                  <p className="text-xs text-muted-foreground">14 днів на повернення</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="description" className="mb-12">
          <TabsList className="w-full justify-start">
            <TabsTrigger value="description" data-testid="tab-description">
              Опис
            </TabsTrigger>
            <TabsTrigger value="specs" data-testid="tab-specs">
              Характеристики
            </TabsTrigger>
          </TabsList>
          <TabsContent value="description" className="mt-6">
            <div className="prose dark:prose-invert max-w-none">
              <p>{product.description}</p>
            </div>
          </TabsContent>
          <TabsContent value="specs" className="mt-6">
            <div className="grid gap-2">
              {Object.entries(product.specifications).map(([key, value]) => (
                <div
                  key={key}
                  className="flex justify-between py-2 border-b last:border-0"
                >
                  <span className="text-muted-foreground">{key}</span>
                  <span className="font-medium">{value}</span>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {relatedProducts && relatedProducts.length > 0 && (
          <section>
            <h2 className="text-2xl font-bold mb-6">Схожі товари</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
              {relatedProducts
                .filter((p) => p.id !== product.id)
                .slice(0, 4)
                .map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}
