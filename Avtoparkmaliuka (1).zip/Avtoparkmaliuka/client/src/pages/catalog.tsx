import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Filter, Grid3X3, List, ChevronRight } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ProductCard } from "@/components/product-card";
import { SubcategoryCard } from "@/components/category-card";
import { FilterPanel } from "@/components/filter-panel";
import type { Category, Product } from "@shared/schema";

type SortOption = "popular" | "price-asc" | "price-desc" | "name";

export default function Catalog() {
  const params = useParams<{ categorySlug?: string; subcategorySlug?: string }>();
  const { categorySlug, subcategorySlug } = params;

  const [selectedBrands, setSelectedBrands] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100000]);
  const [sortBy, setSortBy] = useState<SortOption>("popular");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  const [filtersOpen, setFiltersOpen] = useState(false);

  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const productQueryParams = new URLSearchParams();
  if (categorySlug) productQueryParams.set("category", categorySlug);
  if (subcategorySlug) productQueryParams.set("subcategory", subcategorySlug);
  const productUrl = `/api/products${productQueryParams.toString() ? `?${productQueryParams.toString()}` : ""}`;

  const { data: products, isLoading } = useQuery<Product[]>({
    queryKey: [productUrl],
  });

  const currentCategory = categories?.find((c) => c.slug === categorySlug);
  const currentSubcategory = currentCategory?.subcategories.find((s) => s.slug === subcategorySlug);

  const brands = useMemo(() => {
    if (!products) return [];
    return [...new Set(products.map((p) => p.brand))].sort();
  }, [products]);

  const maxPrice = useMemo(() => {
    if (!products || products.length === 0) return 100000;
    return Math.max(...products.map((p) => p.price));
  }, [products]);

  const filteredProducts = useMemo(() => {
    if (!products) return [];
    
    let filtered = products;
    
    if (selectedBrands.length > 0) {
      filtered = filtered.filter((p) => selectedBrands.includes(p.brand));
    }
    
    filtered = filtered.filter(
      (p) => p.price >= priceRange[0] && p.price <= priceRange[1]
    );

    switch (sortBy) {
      case "price-asc":
        filtered = [...filtered].sort((a, b) => a.price - b.price);
        break;
      case "price-desc":
        filtered = [...filtered].sort((a, b) => b.price - a.price);
        break;
      case "name":
        filtered = [...filtered].sort((a, b) => a.name.localeCompare(b.name));
        break;
      default:
        filtered = [...filtered].sort((a, b) => b.rating - a.rating);
    }

    return filtered;
  }, [products, selectedBrands, priceRange, sortBy]);

  const clearFilters = () => {
    setSelectedBrands([]);
    setPriceRange([0, maxPrice]);
  };

  return (
    <div className="min-h-screen">
      <div className="bg-card border-b py-4">
        <div className="max-w-7xl mx-auto px-4">
          <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-4">
            <Link href="/" className="hover:text-foreground transition-colors">
              Головна
            </Link>
            <ChevronRight className="w-4 h-4" />
            {currentCategory ? (
              <>
                <Link
                  href={`/catalog/${currentCategory.slug}`}
                  className="hover:text-foreground transition-colors"
                >
                  {currentCategory.name}
                </Link>
                {currentSubcategory && (
                  <>
                    <ChevronRight className="w-4 h-4" />
                    <span className="text-foreground">{currentSubcategory.name}</span>
                  </>
                )}
              </>
            ) : (
              <span className="text-foreground">Каталог</span>
            )}
          </nav>

          <h1 className="text-2xl md:text-3xl font-bold">
            {currentSubcategory?.name || currentCategory?.name || "Всі товари"}
          </h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6">
        {currentCategory && !subcategorySlug && currentCategory.subcategories.length > 0 && (
          <div className="mb-8">
            <h2 className="font-semibold mb-4">Підкатегорії</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
              {currentCategory.subcategories.map((sub) => (
                <SubcategoryCard
                  key={sub.id}
                  subcategory={sub}
                  categorySlug={currentCategory.slug}
                />
              ))}
            </div>
          </div>
        )}

        <div className="flex flex-col lg:flex-row gap-6">
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="sticky top-32 bg-card rounded-lg border p-4">
              <FilterPanel
                brands={brands}
                selectedBrands={selectedBrands}
                priceRange={priceRange}
                maxPrice={maxPrice}
                onBrandChange={setSelectedBrands}
                onPriceChange={setPriceRange}
                onClearFilters={clearFilters}
              />
            </div>
          </aside>

          <div className="flex-1">
            <div className="flex items-center justify-between gap-4 mb-6">
              <div className="flex items-center gap-2">
                <Sheet open={filtersOpen} onOpenChange={setFiltersOpen}>
                  <SheetTrigger asChild className="lg:hidden">
                    <Button variant="outline" size="sm" data-testid="button-mobile-filters">
                      <Filter className="w-4 h-4 mr-2" />
                      Фільтри
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-80">
                    <div className="mt-6">
                      <FilterPanel
                        brands={brands}
                        selectedBrands={selectedBrands}
                        priceRange={priceRange}
                        maxPrice={maxPrice}
                        onBrandChange={(b) => { setSelectedBrands(b); }}
                        onPriceChange={(p) => { setPriceRange(p); }}
                        onClearFilters={() => { clearFilters(); setFiltersOpen(false); }}
                      />
                    </div>
                  </SheetContent>
                </Sheet>

                <span className="text-sm text-muted-foreground">
                  {filteredProducts.length} товарів
                </span>
              </div>

              <div className="flex items-center gap-2">
                <Select value={sortBy} onValueChange={(v) => setSortBy(v as SortOption)}>
                  <SelectTrigger className="w-40" data-testid="select-sort">
                    <SelectValue placeholder="Сортування" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="popular">Популярні</SelectItem>
                    <SelectItem value="price-asc">Ціна: низька → висока</SelectItem>
                    <SelectItem value="price-desc">Ціна: висока → низька</SelectItem>
                    <SelectItem value="name">За назвою</SelectItem>
                  </SelectContent>
                </Select>

                <div className="hidden sm:flex border rounded-md">
                  <Button
                    size="icon"
                    variant={viewMode === "grid" ? "secondary" : "ghost"}
                    onClick={() => setViewMode("grid")}
                    data-testid="button-view-grid"
                  >
                    <Grid3X3 className="w-4 h-4" />
                  </Button>
                  <Button
                    size="icon"
                    variant={viewMode === "list" ? "secondary" : "ghost"}
                    onClick={() => setViewMode("list")}
                    data-testid="button-view-list"
                  >
                    <List className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {isLoading ? (
              <div className={`grid gap-4 md:gap-6 ${
                viewMode === "grid"
                  ? "grid-cols-2 md:grid-cols-3"
                  : "grid-cols-1"
              }`}>
                {[...Array(6)].map((_, i) => (
                  <Skeleton key={i} className="h-80 rounded-lg" />
                ))}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground mb-4">
                  Товарів не знайдено
                </p>
                <Button onClick={clearFilters} data-testid="button-clear-filters-empty">
                  Очистити фільтри
                </Button>
              </div>
            ) : (
              <div className={`grid gap-4 md:gap-6 ${
                viewMode === "grid"
                  ? "grid-cols-2 md:grid-cols-3"
                  : "grid-cols-1"
              }`}>
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    categorySlug={categorySlug}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
