import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { HeroCarousel } from "@/components/hero-carousel";
import { CategoryCard } from "@/components/category-card";
import { ProductCard } from "@/components/product-card";
import type { Category, Product } from "@shared/schema";

export default function Home() {
  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });

  const { data: featuredProducts, isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ["/api/products/featured"],
  });

  return (
    <div className="min-h-screen">
      <HeroCarousel />

      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl md:text-3xl font-bold">Категорії товарів</h2>
          <Link href="/catalog">
            <Button variant="ghost" className="gap-2" data-testid="button-all-categories">
              Всі категорії
              <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>

        {categoriesLoading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-40 rounded-lg" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {categories?.slice(0, 10).map((category) => (
              <CategoryCard key={category.id} category={category} />
            ))}
          </div>
        )}
      </section>

      <section className="bg-card py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl md:text-3xl font-bold">Популярні товари</h2>
            <Link href="/catalog">
              <Button variant="ghost" className="gap-2" data-testid="button-all-products">
                Всі товари
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
          </div>

          {productsLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {[...Array(8)].map((_, i) => (
                <Skeleton key={i} className="h-80 rounded-lg" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6">
              {featuredProducts?.slice(0, 8).map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-primary to-primary/80 rounded-lg p-6 text-primary-foreground">
            <div className="text-4xl mb-4">🚚</div>
            <h3 className="font-bold text-lg mb-2">Безкоштовна доставка</h3>
            <p className="text-sm opacity-90">При замовленні від 2000 грн по всій Україні</p>
          </div>
          <div className="bg-gradient-to-br from-secondary to-secondary/80 rounded-lg p-6 text-secondary-foreground">
            <div className="text-4xl mb-4">🛡️</div>
            <h3 className="font-bold text-lg mb-2">Гарантія якості</h3>
            <p className="text-sm opacity-90">Офіційна гарантія на всі товари до 3 років</p>
          </div>
          <div className="bg-gradient-to-br from-accent to-accent/80 rounded-lg p-6 text-accent-foreground">
            <div className="text-4xl mb-4">💳</div>
            <h3 className="font-bold text-lg mb-2">Зручна оплата</h3>
            <p className="text-sm opacity-90">Оплата карткою, готівкою або частинами</p>
          </div>
        </div>
      </section>
    </div>
  );
}
