import { type User, type InsertUser, type Category, type Product, type CartItem } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  getProducts(filters?: ProductFilters): Promise<Product[]>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  getProductById(id: string): Promise<Product | undefined>;
  getFeaturedProducts(): Promise<Product[]>;
  getRelatedProducts(categoryId: string, excludeProductId?: string): Promise<Product[]>;
}

export interface ProductFilters {
  categorySlug?: string;
  subcategorySlug?: string;
  search?: string;
  minPrice?: number;
  maxPrice?: number;
  brands?: string[];
  inStock?: boolean;
  sortBy?: "price_asc" | "price_desc" | "name" | "rating";
}

const categories: Category[] = [
  {
    id: "cat-1",
    name: "Велосипеди",
    slug: "velosypedy",
    icon: "Bike",
    subcategories: [
      { id: "sub-1-1", name: "Дитячі велосипеди", slug: "dytyachi", categoryId: "cat-1" },
      { id: "sub-1-2", name: "Підліткові велосипеди", slug: "pidlitkovi", categoryId: "cat-1" },
      { id: "sub-1-3", name: "BMX велосипеди", slug: "bmx", categoryId: "cat-1" },
      { id: "sub-1-4", name: "Гірські велосипеди", slug: "girski", categoryId: "cat-1" },
    ],
  },
  {
    id: "cat-2",
    name: "Електромобілі",
    slug: "elektromobili",
    icon: "Car",
    subcategories: [
      { id: "sub-2-1", name: "Легкові електромобілі", slug: "legkovi", categoryId: "cat-2" },
      { id: "sub-2-2", name: "Джипи", slug: "dzhypy", categoryId: "cat-2" },
      { id: "sub-2-3", name: "Мотоцикли", slug: "mototsykly", categoryId: "cat-2" },
      { id: "sub-2-4", name: "Квадроцикли", slug: "kvadrotsykly", categoryId: "cat-2" },
    ],
  },
  {
    id: "cat-3",
    name: "Коляски",
    slug: "kolyasky",
    icon: "Baby",
    subcategories: [
      { id: "sub-3-1", name: "Прогулянкові", slug: "progulyankovі", categoryId: "cat-3" },
      { id: "sub-3-2", name: "Коляски 2в1", slug: "2v1", categoryId: "cat-3" },
      { id: "sub-3-3", name: "Коляски 3в1", slug: "3v1", categoryId: "cat-3" },
      { id: "sub-3-4", name: "Для двійні", slug: "dlya-dviyni", categoryId: "cat-3" },
    ],
  },
  {
    id: "cat-4",
    name: "Автокрісла",
    slug: "avtokrisla",
    icon: "Armchair",
    subcategories: [
      { id: "sub-4-1", name: "Група 0+ (0-13 кг)", slug: "grupa-0-plus", categoryId: "cat-4" },
      { id: "sub-4-2", name: "Група 1 (9-18 кг)", slug: "grupa-1", categoryId: "cat-4" },
      { id: "sub-4-3", name: "Група 2-3 (15-36 кг)", slug: "grupa-2-3", categoryId: "cat-4" },
      { id: "sub-4-4", name: "Універсальні", slug: "universalni", categoryId: "cat-4" },
    ],
  },
  {
    id: "cat-5",
    name: "Дитячий транспорт",
    slug: "dytyachyy-transport",
    icon: "Footprints",
    subcategories: [
      { id: "sub-5-1", name: "Самокати", slug: "samokaty", categoryId: "cat-5" },
      { id: "sub-5-2", name: "Біговели", slug: "bihovely", categoryId: "cat-5" },
      { id: "sub-5-3", name: "Толокари", slug: "tolokary", categoryId: "cat-5" },
      { id: "sub-5-4", name: "Гойдалки", slug: "goydalky", categoryId: "cat-5" },
    ],
  },
  {
    id: "cat-6",
    name: "Ліжка",
    slug: "lizhka",
    icon: "Bed",
    subcategories: [
      { id: "sub-6-1", name: "Дитячі ліжечка", slug: "dytyachi-lizhechka", categoryId: "cat-6" },
      { id: "sub-6-2", name: "Підліткові ліжка", slug: "pidlitkovi-lizhka", categoryId: "cat-6" },
      { id: "sub-6-3", name: "Двоярусні ліжка", slug: "dvoyarusni", categoryId: "cat-6" },
    ],
  },
  {
    id: "cat-7",
    name: "Стільчики",
    slug: "stilchyky",
    icon: "Utensils",
    subcategories: [
      { id: "sub-7-1", name: "Для годування", slug: "dlya-goduvannya", categoryId: "cat-7" },
      { id: "sub-7-2", name: "Шезлонги", slug: "shezlongy", categoryId: "cat-7" },
      { id: "sub-7-3", name: "Качелі", slug: "kacheli", categoryId: "cat-7" },
    ],
  },
  {
    id: "cat-8",
    name: "Іграшки",
    slug: "igrashky",
    icon: "Gamepad2",
    subcategories: [
      { id: "sub-8-1", name: "Розвиваючі", slug: "rozvyvayuchi", categoryId: "cat-8" },
      { id: "sub-8-2", name: "Конструктори", slug: "konstruktory", categoryId: "cat-8" },
      { id: "sub-8-3", name: "Ляльки", slug: "lyalky", categoryId: "cat-8" },
      { id: "sub-8-4", name: "Машинки", slug: "mashynky", categoryId: "cat-8" },
    ],
  },
];

const products: Product[] = [
  {
    id: "prod-1",
    name: "Велосипед дитячий Royal Baby Freestyle 16\"",
    slug: "royal-baby-freestyle-16",
    description: "Якісний дитячий велосипед з алюмінієвою рамою та допоміжними колесами. Підходить для дітей віком 4-6 років. Надійні гальма, зручне сидіння з регулюванням висоти.",
    price: 6499,
    oldPrice: 7299,
    images: ["https://placehold.co/600x600/22c55e/white?text=Велосипед+1"],
    categoryId: "cat-1",
    subcategoryId: "sub-1-1",
    brand: "Royal Baby",
    inStock: true,
    specifications: { "Діаметр коліс": "16 дюймів", "Матеріал рами": "Алюміній", "Вага": "9.5 кг", "Вік": "4-6 років" },
    rating: 4.8,
    reviewCount: 124,
  },
  {
    id: "prod-2",
    name: "Велосипед Pride Brave 20\"",
    slug: "pride-brave-20",
    description: "Підлітковий велосипед з міцною сталевою рамою. Ідеально підходить для активного відпочинку та навчання.",
    price: 8999,
    images: ["https://placehold.co/600x600/22c55e/white?text=Велосипед+2"],
    categoryId: "cat-1",
    subcategoryId: "sub-1-2",
    brand: "Pride",
    inStock: true,
    specifications: { "Діаметр коліс": "20 дюймів", "Матеріал рами": "Сталь", "Вага": "12 кг", "Вік": "7-10 років" },
    rating: 4.5,
    reviewCount: 89,
  },
  {
    id: "prod-3",
    name: "Електромобіль Mercedes-Benz AMG GT",
    slug: "mercedes-benz-amg-gt",
    description: "Стильний дитячий електромобіль з реалістичним дизайном. Два мотори, пульт дистанційного керування, LED-фари, MP3.",
    price: 12999,
    oldPrice: 14999,
    images: ["https://placehold.co/600x600/f97316/white?text=Електромобіль+1"],
    categoryId: "cat-2",
    subcategoryId: "sub-2-1",
    brand: "Mercedes-Benz",
    inStock: true,
    specifications: { "Потужність": "2x35W", "Акумулятор": "12V 7Ah", "Швидкість": "до 5 км/год", "Вік": "3-8 років" },
    rating: 4.9,
    reviewCount: 67,
  },
  {
    id: "prod-4",
    name: "Електромобіль Jeep Wrangler 4x4",
    slug: "jeep-wrangler-4x4",
    description: "Потужний дитячий джип з повним приводом. Їздить по будь-яких поверхнях. Шкіряне сидіння, Bluetooth.",
    price: 18499,
    images: ["https://placehold.co/600x600/f97316/white?text=Джип+1"],
    categoryId: "cat-2",
    subcategoryId: "sub-2-2",
    brand: "Jeep",
    inStock: true,
    specifications: { "Потужність": "4x45W", "Акумулятор": "12V 10Ah", "Швидкість": "до 7 км/год", "Вік": "3-10 років" },
    rating: 4.7,
    reviewCount: 45,
  },
  {
    id: "prod-5",
    name: "Коляска Cybex Balios S Lux",
    slug: "cybex-balios-s-lux",
    description: "Преміальна прогулянкова коляска з великим капюшоном. Компактне складання однією рукою. Висока посадка.",
    price: 19999,
    oldPrice: 22999,
    images: ["https://placehold.co/600x600/6366f1/white?text=Коляска+1"],
    categoryId: "cat-3",
    subcategoryId: "sub-3-1",
    brand: "Cybex",
    inStock: true,
    specifications: { "Тип": "Прогулянкова", "Вага": "9.3 кг", "Складання": "Книжка", "Максимальне навантаження": "22 кг" },
    rating: 4.9,
    reviewCount: 156,
  },
  {
    id: "prod-6",
    name: "Коляска Anex e/type 2в1",
    slug: "anex-etype-2v1",
    description: "Універсальна коляска 2в1 з люлькою та прогулянковим блоком. Великі надувні колеса, амортизація.",
    price: 32999,
    images: ["https://placehold.co/600x600/6366f1/white?text=Коляска+2"],
    categoryId: "cat-3",
    subcategoryId: "sub-3-2",
    brand: "Anex",
    inStock: true,
    specifications: { "Тип": "2в1", "Вага": "14 кг", "Колеса": "Надувні", "Комплектація": "Люлька + прогулянка" },
    rating: 4.8,
    reviewCount: 98,
  },
  {
    id: "prod-7",
    name: "Автокрісло Britax Römer Baby-Safe",
    slug: "britax-romer-baby-safe",
    description: "Автолюлька для новонароджених з системою ISOFIX. Найвищий рівень безпеки, підтверджений краш-тестами.",
    price: 8999,
    images: ["https://placehold.co/600x600/ec4899/white?text=Автокрісло+1"],
    categoryId: "cat-4",
    subcategoryId: "sub-4-1",
    brand: "Britax Römer",
    inStock: true,
    specifications: { "Група": "0+ (0-13 кг)", "Кріплення": "ISOFIX", "Вага": "4.8 кг", "Вік": "0-15 місяців" },
    rating: 4.9,
    reviewCount: 203,
  },
  {
    id: "prod-8",
    name: "Автокрісло Maxi-Cosi Pearl 360",
    slug: "maxi-cosi-pearl-360",
    description: "Поворотне автокрісло на 360° для зручного розміщення дитини. I-Size стандарт безпеки.",
    price: 15999,
    oldPrice: 17999,
    images: ["https://placehold.co/600x600/ec4899/white?text=Автокрісло+2"],
    categoryId: "cat-4",
    subcategoryId: "sub-4-2",
    brand: "Maxi-Cosi",
    inStock: true,
    specifications: { "Група": "1 (9-18 кг)", "Кріплення": "ISOFIX + поворот 360°", "Вага": "12.5 кг", "Вік": "4 місяці - 4 роки" },
    rating: 4.7,
    reviewCount: 87,
  },
  {
    id: "prod-9",
    name: "Самокат Micro Maxi Deluxe",
    slug: "micro-maxi-deluxe",
    description: "Преміальний дитячий самокат зі швейцарською якістю. Унікальна система нахилу для повороту, гальмо.",
    price: 4999,
    images: ["https://placehold.co/600x600/8b5cf6/white?text=Самокат+1"],
    categoryId: "cat-5",
    subcategoryId: "sub-5-1",
    brand: "Micro",
    inStock: true,
    specifications: { "Тип": "Триколісний", "Навантаження": "до 70 кг", "Вага": "2.5 кг", "Вік": "5-12 років" },
    rating: 4.9,
    reviewCount: 312,
  },
  {
    id: "prod-10",
    name: "Біговел Strider Classic 12\"",
    slug: "strider-classic-12",
    description: "Класичний біговел для розвитку балансу. Регулювання сидіння та керма. Легкий та міцний.",
    price: 2999,
    oldPrice: 3499,
    images: ["https://placehold.co/600x600/8b5cf6/white?text=Біговел+1"],
    categoryId: "cat-5",
    subcategoryId: "sub-5-2",
    brand: "Strider",
    inStock: true,
    specifications: { "Діаметр коліс": "12 дюймів", "Вага": "3 кг", "Вік": "1.5-5 років", "Висота сидіння": "28-41 см" },
    rating: 4.8,
    reviewCount: 178,
  },
  {
    id: "prod-11",
    name: "Ліжечко Inglesina Мy Junior",
    slug: "inglesina-my-junior",
    description: "Стильне дитяче ліжечко з бука. Регулювання дна на 3 рівні. Знімні бортики.",
    price: 11999,
    images: ["https://placehold.co/600x600/14b8a6/white?text=Ліжечко+1"],
    categoryId: "cat-6",
    subcategoryId: "sub-6-1",
    brand: "Inglesina",
    inStock: true,
    specifications: { "Матеріал": "Бук", "Розмір матраса": "120x60 см", "Рівні дна": "3", "Вік": "0-3 роки" },
    rating: 4.6,
    reviewCount: 54,
  },
  {
    id: "prod-12",
    name: "Стільчик Peg Perego Prima Pappa",
    slug: "peg-perego-prima-pappa",
    description: "Багатофункціональний стільчик для годування. 7 положень висоти, відкидна спинка, знімний столик.",
    price: 7499,
    oldPrice: 8499,
    images: ["https://placehold.co/600x600/f59e0b/white?text=Стільчик+1"],
    categoryId: "cat-7",
    subcategoryId: "sub-7-1",
    brand: "Peg Perego",
    inStock: true,
    specifications: { "Положень висоти": "7", "Положень спинки": "4", "Вага": "9.5 кг", "Вік": "6 місяців - 3 роки" },
    rating: 4.7,
    reviewCount: 143,
  },
  {
    id: "prod-13",
    name: "Конструктор LEGO Duplo Поїзд",
    slug: "lego-duplo-train",
    description: "Розвиваючий конструктор для малюків. Великі деталі, безпечні для найменших. Звукові ефекти.",
    price: 1899,
    images: ["https://placehold.co/600x600/eab308/white?text=LEGO+Duplo"],
    categoryId: "cat-8",
    subcategoryId: "sub-8-2",
    brand: "LEGO",
    inStock: true,
    specifications: { "Кількість деталей": "59", "Вік": "2-5 років", "Серія": "Duplo", "Тема": "Поїзди" },
    rating: 4.9,
    reviewCount: 287,
  },
  {
    id: "prod-14",
    name: "Електромотоцикл BMW S1000RR",
    slug: "bmw-s1000rr-moto",
    description: "Стильний дитячий електромотоцикл BMW. Світлові та звукові ефекти, допоміжні колеса.",
    price: 5999,
    oldPrice: 6999,
    images: ["https://placehold.co/600x600/f97316/white?text=Мотоцикл+1"],
    categoryId: "cat-2",
    subcategoryId: "sub-2-3",
    brand: "BMW",
    inStock: true,
    specifications: { "Потужність": "25W", "Акумулятор": "6V 4.5Ah", "Швидкість": "до 3 км/год", "Вік": "2-5 років" },
    rating: 4.6,
    reviewCount: 76,
  },
  {
    id: "prod-15",
    name: "Велосипед BMX Haro Shredder Pro",
    slug: "haro-shredder-pro",
    description: "Професійний BMX для трюків та стріт-райдингу. Хромомолібденова рама, пеги в комплекті.",
    price: 14999,
    images: ["https://placehold.co/600x600/22c55e/white?text=BMX+1"],
    categoryId: "cat-1",
    subcategoryId: "sub-1-3",
    brand: "Haro",
    inStock: true,
    specifications: { "Діаметр коліс": "20 дюймів", "Матеріал рами": "Cr-Mo", "Вага": "11.2 кг", "Вік": "10+ років" },
    rating: 4.8,
    reviewCount: 34,
  },
  {
    id: "prod-16",
    name: "Толокар Mercedes-Benz GL63 AMG",
    slug: "mercedes-tolokаr",
    description: "Стильний толокар з батьківською ручкою. Музичний кермо, багажник, захисний бампер.",
    price: 2499,
    images: ["https://placehold.co/600x600/8b5cf6/white?text=Толокар+1"],
    categoryId: "cat-5",
    subcategoryId: "sub-5-3",
    brand: "Mercedes-Benz",
    inStock: true,
    specifications: { "Навантаження": "до 25 кг", "Вага": "4.5 кг", "Вік": "1-3 роки", "Ручка": "Батьківська" },
    rating: 4.5,
    reviewCount: 112,
  },
];

export class MemStorage implements IStorage {
  private users: Map<string, User>;

  constructor() {
    this.users = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getCategories(): Promise<Category[]> {
    return categories;
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return categories.find((c) => c.slug === slug);
  }

  async getProducts(filters?: ProductFilters): Promise<Product[]> {
    let result = [...products];

    if (filters?.categorySlug) {
      const category = categories.find((c) => c.slug === filters.categorySlug);
      if (category) {
        result = result.filter((p) => p.categoryId === category.id);
      }
    }

    if (filters?.subcategorySlug) {
      const category = categories.find((c) => 
        c.subcategories.some((s) => s.slug === filters.subcategorySlug)
      );
      if (category) {
        const subcategory = category.subcategories.find((s) => s.slug === filters.subcategorySlug);
        if (subcategory) {
          result = result.filter((p) => p.subcategoryId === subcategory.id);
        }
      }
    }

    if (filters?.search) {
      const searchLower = filters.search.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(searchLower) ||
          p.description.toLowerCase().includes(searchLower) ||
          p.brand.toLowerCase().includes(searchLower)
      );
    }

    if (filters?.minPrice !== undefined) {
      result = result.filter((p) => p.price >= filters.minPrice!);
    }

    if (filters?.maxPrice !== undefined) {
      result = result.filter((p) => p.price <= filters.maxPrice!);
    }

    if (filters?.brands && filters.brands.length > 0) {
      result = result.filter((p) => filters.brands!.includes(p.brand));
    }

    if (filters?.inStock !== undefined) {
      result = result.filter((p) => p.inStock === filters.inStock);
    }

    if (filters?.sortBy) {
      switch (filters.sortBy) {
        case "price_asc":
          result.sort((a, b) => a.price - b.price);
          break;
        case "price_desc":
          result.sort((a, b) => b.price - a.price);
          break;
        case "name":
          result.sort((a, b) => a.name.localeCompare(b.name));
          break;
        case "rating":
          result.sort((a, b) => b.rating - a.rating);
          break;
      }
    }

    return result;
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return products.find((p) => p.slug === slug);
  }

  async getProductById(id: string): Promise<Product | undefined> {
    return products.find((p) => p.id === id);
  }

  async getFeaturedProducts(): Promise<Product[]> {
    return products.filter((p) => p.rating >= 4.7).slice(0, 8);
  }

  async getRelatedProducts(categoryId: string, excludeProductId?: string): Promise<Product[]> {
    return products
      .filter((p) => p.categoryId === categoryId && p.id !== excludeProductId)
      .slice(0, 8);
  }
}

export const storage = new MemStorage();
