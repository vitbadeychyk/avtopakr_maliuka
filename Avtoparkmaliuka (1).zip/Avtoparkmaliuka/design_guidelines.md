# Design Guidelines: Children's Products E-Commerce Store

## Design Approach
**System Selected:** Material Design with playful modifications for children's products
**Justification:** E-commerce requires familiar patterns for trust and usability, while children's products demand warmth and playfulness. Material Design provides robust component library with flexibility for brand personality.

## Core Design Elements

### Typography
**Font Stack:**
- Primary: 'Nunito' (Google Fonts) - friendly, rounded sans-serif perfect for children's brand
- Weights: 400 (regular), 600 (semi-bold), 700 (bold), 800 (extra-bold)

**Hierarchy:**
- H1: 800 weight, 36px (mobile) / 48px (desktop) - Hero headlines
- H2: 700 weight, 28px (mobile) / 36px (desktop) - Section titles
- H3: 700 weight, 24px (mobile) / 28px (desktop) - Product category headers
- H4: 600 weight, 20px (mobile) / 24px (desktop) - Card titles
- Body: 400 weight, 16px - Product descriptions, general content
- Small: 400 weight, 14px - Metadata, labels, filters

### Layout System
**Spacing Units:** Tailwind: 2, 4, 6, 8, 12, 16, 20, 24 for consistent rhythm
- Component padding: p-4 (mobile), p-6 or p-8 (desktop)
- Section spacing: py-12 (mobile), py-16 or py-20 (desktop)
- Card gaps: gap-4 (mobile), gap-6 (desktop)
- Container: max-w-7xl with px-4 (mobile), px-6 (desktop)

**Grid System:**
- Product grids: 1 column (mobile), 2 columns (md), 3-4 columns (lg)
- Category navigation: Flexible grid adapting to content
- Filters sidebar: Collapsible on mobile, fixed left on desktop

### Component Library

#### Navigation
**Header:**
- Logo (left), Search bar (center), Cart/Account icons (right)
- Main navigation below logo: Horizontal mega-menu on desktop
- Mobile: Hamburger menu with slide-out drawer
- Sticky header on scroll with subtle shadow
- Category dropdown menus with image thumbnails + text labels

**Mega Menu Structure:**
- Full-width dropdown panels
- Categories displayed in multi-column grid (3-4 columns)
- Each category shows small icon/image + category name
- Subcategories listed below parent in lighter text

#### Product Cards
- Aspect ratio: 4:3 for product images
- Rounded corners: rounded-xl
- Subtle shadow on hover: shadow-md → shadow-xl transition
- Structure: Image → Category tag → Product name → Price → "Add to Cart" button
- Price display: Bold, larger font, positioned prominently
- Sale badges: Positioned top-right corner with bright accent treatment

#### Filters & Search
**Filter Panel:**
- Collapsible sections with chevron indicators
- Checkboxes for multi-select options
- Price range slider with min/max inputs
- Brand filter with search capability
- Clear all filters button at bottom

**Search:**
- Prominent search bar in header (35-40% width on desktop)
- Search icon on left, clear button on right when typing
- Autocomplete dropdown showing suggested products with thumbnails
- Recent searches displayed when clicking empty search

#### Shopping Cart
**Cart Icon:**
- Badge showing item count (top-right of icon)
- Slide-out drawer from right on click (desktop)
- Full page on mobile

**Cart Contents:**
- Product thumbnail (left) + name, price, quantity controls (right)
- Subtotal prominently displayed
- Estimated shipping info
- "Proceed to Checkout" CTA button (large, prominent)

#### Buttons
**Primary CTA (Add to Cart, Checkout):**
- Rounded-lg borders
- Medium padding: px-6 py-3
- Font weight: 600
- Full width on mobile, auto width on desktop

**Secondary (View Details, Continue Shopping):**
- Outlined style with 2px border
- Same sizing as primary
- Hover: filled background

**Icon Buttons:**
- Consistent 44px × 44px touch target
- Rounded-full for circular treatment
- Used for favorites, cart, account icons

#### Product Detail Page
- Image gallery: Large primary image (left 60%) + thumbnail carousel below
- Product info panel (right 40%): Name, price, description, specs, quantity selector, add to cart
- Tabs below for: Description, Specifications, Reviews, Delivery Info
- Related products carousel at bottom

#### Hero Section
**Layout:**
- Large banner carousel (full-width, 60vh height)
- Multiple promotional slides
- Manual navigation dots + auto-advance (5 seconds)
- CTA buttons overlaid on images with frosted glass/blur background (backdrop-blur-md with semi-transparent bg)

**Images:**
- Use vibrant lifestyle photography showing children using products
- Hero images should feature: happy children on bicycles, playing with electric cars, babies in strollers
- Professional product photography with clean backgrounds
- Lifestyle imagery creating emotional connection with parents

#### Category Pages
- Breadcrumb navigation at top
- Category hero banner (shorter, 30vh)
- Filter panel (left sidebar, 25% width on desktop)
- Product grid (right, 75% width)
- Pagination at bottom (numbers + prev/next arrows)
- Products per page selector: 12, 24, 48 options

#### Footer
**Multi-column layout (stacks on mobile):**
- Column 1: About Us, Contact info, Social media icons
- Column 2: Customer Service links (Shipping, Returns, FAQ)
- Column 3: Product Categories (top-level links)
- Column 4: Newsletter signup with email input + subscribe button
- Bottom bar: Copyright, Payment methods icons, Trust badges

### Interaction Patterns
- Smooth transitions: transition-all duration-300
- Hover states: Scale product cards slightly (scale-105), brighten colors
- Loading states: Skeleton screens for products, spinner for actions
- Toast notifications: Top-right corner for cart additions, success/error messages
- Image zoom: Click product images to view larger in modal/lightbox

### Accessibility
- ARIA labels on all interactive elements
- Keyboard navigation support (tab order, enter/space for actions)
- Alt text for all product images
- Sufficient contrast ratios (WCAG AA minimum)
- Focus indicators visible on all focusable elements
- Form inputs with clear labels above inputs

### Images
**Required Images:**
- Hero carousel: 3-5 lifestyle banners showing children with products (bicycles, electric cars, playing)
- Category thumbnails: Small icons/images for each main category in navigation
- Product images: Multiple angles per product (minimum 3-4 images)
- Promotional banners: Seasonal sales, featured categories
- Brand logos: Payment methods, shipping partners in footer
- Trust indicators: Security badges, customer review stars

**Image Specifications:**
- Hero: 1920×1080px minimum, optimized for web
- Products: 800×800px, white/neutral background
- Category thumbnails: 200×200px
- All images: WebP format with fallbacks, lazy loading below fold