import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export interface Category {
  id: string;
  name: string;
  slug: string;
  icon: string;
  image?: string;
  subcategories: Subcategory[];
}

export interface Subcategory {
  id: string;
  name: string;
  slug: string;
  categoryId: string;
  image?: string;
}

export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  oldPrice?: number;
  images: string[];
  categoryId: string;
  subcategoryId: string;
  brand: string;
  inStock: boolean;
  specifications: Record<string, string>;
  rating: number;
  reviewCount: number;
}

export interface CartItem {
  productId: string;
  quantity: number;
}

export interface Cart {
  items: CartItem[];
}

export const insertProductSchema = z.object({
  name: z.string().min(1),
  slug: z.string().min(1),
  description: z.string(),
  price: z.number().positive(),
  oldPrice: z.number().positive().optional(),
  images: z.array(z.string()),
  categoryId: z.string(),
  subcategoryId: z.string(),
  brand: z.string(),
  inStock: z.boolean().default(true),
  specifications: z.record(z.string(), z.string()),
  rating: z.number().min(0).max(5).default(0),
  reviewCount: z.number().int().min(0).default(0),
});

export type InsertProduct = z.infer<typeof insertProductSchema>;

export const cartItemSchema = z.object({
  productId: z.string(),
  quantity: z.number().int().positive(),
});

export type InsertCartItem = z.infer<typeof cartItemSchema>;
